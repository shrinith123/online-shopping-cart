package project;
import java.sql.*;

public class Connectionprovider {
	public static Connection getCon()
	{
		try
		{
			Class.forName("com.msql.cj.jddbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql:localhost:3306/ospjsp","root","123456789");
			return con;
		}
		catch(Exception e)
		{
			System.out.print(e);
			return null;
		
		}
	}

}
